/*
 * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.gradle.composite.internal;

import com.google.common.collect.Maps;
import org.gradle.api.artifacts.component.ProjectComponentIdentifier;
import org.gradle.initialization.ProjectPathRegistry;
import org.gradle.util.Path;

import java.util.Map;
import java.util.Set;

public class DefaultProjectPathRegistry implements ProjectPathRegistry {
    private final Map<Path, ProjectComponentIdentifier> allProjects = Maps.newLinkedHashMap();

    void add(Path projectIdentityPath, ProjectComponentIdentifier identifier) {
        allProjects.put(projectIdentityPath, identifier);
    }

    @Override
    public Set<Path> getAllProjectPaths() {
        return allProjects.keySet();
    }

    @Override
    public ProjectComponentIdentifier getProjectComponentIdentifier(Path identityPath) {
        return allProjects.get(identityPath);
    }
}
