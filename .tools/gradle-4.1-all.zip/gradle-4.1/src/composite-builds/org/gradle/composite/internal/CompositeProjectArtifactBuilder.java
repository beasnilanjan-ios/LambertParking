/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.composite.internal;

import org.gradle.api.internal.artifacts.ivyservice.projectmodule.ProjectArtifactBuilder;
import org.gradle.initialization.BuildIdentity;
import org.gradle.internal.component.model.ComponentArtifactMetadata;

class CompositeProjectArtifactBuilder implements ProjectArtifactBuilder {
    private final IncludedBuildArtifactBuilder artifactBuilder;
    private final BuildIdentity buildIdentity;

    CompositeProjectArtifactBuilder(IncludedBuildArtifactBuilder artifactBuilder, BuildIdentity buildIdentity) {
        this.artifactBuilder = artifactBuilder;
        this.buildIdentity = buildIdentity;
    }

    @Override
    public void build(ComponentArtifactMetadata artifact) {
        artifactBuilder.build(buildIdentity.getCurrentBuild(), artifact);
    }
}
